package com.example.sataligner;

import android.app.Activity;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;

public class GuidanceActivity extends Activity {
    private CompassManager compassManager;
    private TextView tvCurrentValues;
    private EditText etTargetAzimuth, etTargetElevation;
    private RadarVectorView radarView;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private float targetAzimuth = 0f;
    private float targetElevation = 0f;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Color.parseColor("#121212"));
        root.setPadding(32, 32, 32, 32);

        tvCurrentValues = new TextView(this);
        tvCurrentValues.setTextColor(Color.WHITE);
        tvCurrentValues.setTextSize(16);
        root.addView(tvCurrentValues);

        etTargetAzimuth = new EditText(this);
        etTargetAzimuth.setHint("Target Azimuth");
        etTargetAzimuth.setTextColor(Color.WHITE);
        root.addView(etTargetAzimuth);

        etTargetElevation = new EditText(this);
        etTargetElevation.setHint("Target Elevation");
        etTargetElevation.setTextColor(Color.WHITE);
        root.addView(etTargetElevation);

        Button btnApply = new Button(this);
        btnApply.setText("SET TARGET");
        btnApply.setOnClickListener(v -> {
            try {
                targetAzimuth = Float.parseFloat(etTargetAzimuth.getText().toString());
                targetElevation = Float.parseFloat(etTargetElevation.getText().toString());
            } catch (NumberFormatException ignored) {}
        });
        root.addView(btnApply);

        radarView = new RadarVectorView(this);
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(-1, 600);
        params.topMargin = 50;
        radarView.setLayoutParams(params);
        root.addView(radarView);

        setContentView(root);
        compassManager = CompassManager.getInstance(this);
    }

    @Override
    protected void onResume() {
        super.onResume();
        compassManager.start();
        startUpdateLoop();
    }

    @Override
    protected void onPause() {
        super.onPause();
        compassManager.stop();
        handler.removeCallbacksAndMessages(null);
    }

    private void startUpdateLoop() {
        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                float curAzimuth = compassManager.getAzimuthDegrees();
                float curPitch = compassManager.getPitchDegrees();
                tvCurrentValues.setText("Azimuth: " + curAzimuth + "\nElevation: " + curPitch);
                radarView.updateData(curAzimuth, curPitch, targetAzimuth, targetElevation);
                handler.postDelayed(this, 30);
            }
        }, 30);
    }

    private static class RadarVectorView extends View {
        private float curAz, curEl, tarAz, tarEl;
        private final Paint pCircle = new Paint();
        private final Paint pArrow = new Paint();

        public RadarVectorView(Context context) {
            super(context);
            pCircle.setColor(Color.DKGRAY);
            pCircle.setStyle(Paint.Style.STROKE);
            pCircle.setStrokeWidth(5f);
            pArrow.setColor(Color.GREEN);
            pArrow.setStrokeWidth(10f);
        }

        public void updateData(float cz, float ce, float tz, float te) {
            this.curAz = cz; this.curEl = ce; this.tarAz = tz; this.tarEl = te;
            invalidate();
        }

        @Override
        protected void onDraw(Canvas canvas) {
            super.onDraw(canvas);
            int cx = getWidth() / 2;
            int cy = getHeight() / 2;
            canvas.drawCircle(cx, cy, 150, pCircle);
            float dAz = tarAz - curAz;
            float dEl = tarEl - curEl;
            canvas.save();
            canvas.rotate(dAz, cx, cy);
            float len = 150f - (dEl * 2f);
            if(len < 30) len = 30;
            canvas.drawLine(cx, cy, cx, cy - len, pArrow);
            canvas.restore();
        }
    }
}

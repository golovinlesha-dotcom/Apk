package com.example.sataligner;

import android.app.Activity;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.TextView;

public class SunCalibrationActivity extends Activity {
    private CompassManager compassManager;
    private SolarView solarView;
    private TextView tvStatus, tvPromptArrows;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private double sunAzimuth = 180.0;
    private double sunElevation = 45.0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(Color.BLACK);

        solarView = new SolarView(this);
        root.addView(solarView);

        tvStatus = new TextView(this);
        tvStatus.setTextColor(Color.WHITE);
        tvStatus.setPadding(20, 20, 20, 20);
        root.addView(tvStatus);

        tvPromptArrows = new TextView(this);
        tvPromptArrows.setTextColor(Color.YELLOW);
        tvPromptArrows.setTextSize(32);
        tvPromptArrows.setPadding(0, 200, 0, 0);
        tvPromptArrows.setTextAlignment(View.TEXT_ALIGNMENT_CENTER);
        root.addView(tvPromptArrows);

        setContentView(root);
        compassManager = CompassManager.getInstance(this);
    }

    @Override
    protected void onResume() {
        super.onResume();
        compassManager.start();
        startLoop();
    }

    @Override
    protected void onPause() {
        super.onPause();
        compassManager.stop();
        handler.removeCallbacksAndMessages(null);
    }

    private void startLoop() {
        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                float devAzimuth = compassManager.getAzimuthDegrees();
                float devPitch = compassManager.getPitchDegrees();
                double diffAz = sunAzimuth - devAzimuth;
                double diffEl = sunElevation - devPitch;

                tvStatus.setText("Target Sun: Az=" + sunAzimuth + " El=" + sunElevation + "\nDevice: Az=" + devAzimuth + " El=" + devPitch);

                StringBuilder arrows = new StringBuilder();
                if (diffAz > 3) arrows.append("RIGHT ");
                else if (diffAz < -3) arrows.append("LEFT ");
                if (diffEl > 3) arrows.append("UP");
                else if (diffEl < -3) arrows.append("DOWN");

                if (Math.abs(diffAz) <= 3 && Math.abs(diffEl) <= 3) {
                    arrows.setLength(0);
                    arrows.append("MATCHED! Gyro Reset.");
                    compassManager.resetAzimuth((float) sunAzimuth);
                }

                tvPromptArrows.setText(arrows.toString());
                solarView.updatePositions((float) diffAz, (float) diffEl);
                handler.postDelayed(this, 40);
            }
        }, 40);
    }

    private static class SolarView extends View {
        private float offsetX = 0, offsetY = 0;
        private final Paint pGrey = new Paint();
        private final Paint pWhite = new Paint();

        public SolarView(Context context) {
            super(context);
            pGrey.setColor(Color.LTGRAY);
            pGrey.setStyle(Paint.Style.STROKE);
            pGrey.setStrokeWidth(8f);
            pWhite.setColor(Color.WHITE);
            pWhite.setStyle(Paint.Style.FILL);
        }

        public void updatePositions(float diffAz, float diffEl) {
            this.offsetX = diffAz * 15f;
            this.offsetY = -diffEl * 15f;
            invalidate();
        }

        @Override
        protected void onDraw(Canvas canvas) {
            super.onDraw(canvas);
            int cx = getWidth() / 2;
            int cy = getHeight() / 2;
            canvas.drawCircle(cx, cy, 100, pGrey);
            canvas.drawCircle(cx + offsetX, cy + offsetY, 80, pWhite);
        }
    }
}

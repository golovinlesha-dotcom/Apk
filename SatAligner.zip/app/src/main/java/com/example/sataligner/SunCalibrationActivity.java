package com.example.sataligner;
import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
public class SunCalibrationActivity extends AppCompatActivity {
    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }
}

package com.example.sataligner;

import android.content.Context;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;

public class CompassManager implements SensorEventListener {
    private static CompassManager instance;
    private final SensorManager sensorManager;
    private float azimuth = 0;
    private float pitch = 0;
    private float roll = 0;
    private long lastTimestamp = 0;

    private CompassManager(Context context) {
        sensorManager = (SensorManager) context.getSystemService(Context.SENSOR_SERVICE);
    }

    public static synchronized CompassManager getInstance(Context context) {
        if (instance == null) instance = new CompassManager(context.getApplicationContext());
        return instance;
    }

    public void start() {
        Sensor accel = sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);
        Sensor gyro = sensorManager.getDefaultSensor(Sensor.TYPE_GYROSCOPE);
        sensorManager.registerListener(this, accel, SensorManager.SENSOR_DELAY_GAME);
        sensorManager.registerListener(this, gyro, SensorManager.SENSOR_DELAY_GAME);
    }

    public void stop() {
        sensorManager.unregisterListener(this);
    }

    public void resetAzimuth(float trueAzimuthDegrees) {
        this.azimuth = (float) Math.toRadians(trueAzimuthDegrees);
    }

    @Override
    public void onSensorChanged(SensorEvent event) {
        if (event.sensor.getType() == Sensor.TYPE_ACCELEROMETER) {
            pitch = (float) Math.atan2(event.values[0], event.values[2]);
            roll = (float) Math.atan2(-event.values[1], Math.sqrt(event.values[0]*event.values[0] + event.values[2]*event.values[2]));
        }
        if (event.sensor.getType() == Sensor.TYPE_GYROSCOPE) {
            if (lastTimestamp != 0) {
                float dT = (event.timestamp - lastTimestamp) * (1.0f / 1000000000.0f);
                azimuth += event.values[2] * dT; 
            }
            lastTimestamp = event.timestamp;
        }
    }

    @Override
    public void onAccuracyChanged(Sensor sensor, int accuracy) {}

    public float getAzimuthDegrees() { return (float) Math.toDegrees(azimuth); }
    public float getPitchDegrees() { return (float) Math.toDegrees(pitch); }
    public float getRollDegrees() { return (float) Math.toDegrees(roll); }
}

package com.example.sataligner;

import java.util.Calendar;
import java.util.TimeZone;

public class SolarPositionCalculator {
    public static class SolarPosition {
        public double azimuth;
        public double elevation;
    }

    public static SolarPosition calculateSolarPosition(double lat, double lon) {
        SolarPosition pos = new SolarPosition();
        Calendar cal = Calendar.getInstance(TimeZone.getTimeZone("UTC"));
        int dayOfYear = cal.get(Calendar.DAY_OF_YEAR);
        double hourInUtc = cal.get(Calendar.HOUR_OF_DAY) + cal.get(Calendar.MINUTE) / 60.0;

        double declination = 23.45 * Math.sin(Math.toRadians((360.0 / 365.0) * (dayOfYear - 81)));
        double b = Math.toRadians((360.0 / 365.0) * (dayOfYear - 81));
        double equationOfTime = 9.87 * Math.sin(2 * b) - 7.53 * Math.cos(b) - 1.5 * Math.sin(b);

        double solarTimeFix = equationOfTime + 4.0 * lon;
        double localSolarTime = hourInUtc * 60.0 + solarTimeFix;
        double hourAngle = Math.toRadians((localSolarTime / 4.0) - 180.0);

        double latRad = Math.toRadians(lat);
        double decRad = Math.toRadians(declination);

        double sinElevation = Math.sin(latRad) * Math.sin(decRad) + Math.cos(latRad) * Math.cos(decRad) * Math.cos(hourAngle);
        pos.elevation = Math.toDegrees(Math.asin(sinElevation));

        double cosAzimuth = (Math.sin(decRad) - Math.sin(latRad) * sinElevation) / (Math.cos(latRad) * Math.cos(Math.asin(sinElevation)));
        double azimuth = Math.toDegrees(Math.acos(cosAzimuth));
        
        pos.azimuth = (Math.sin(hourAngle) > 0) ? (360.0 - azimuth) : azimuth;
        return pos;
    }
}

package com.example.sataligner;

import android.content.Intent;
import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        findViewById(R.id.btnSunCalib).setOnClickListener(v -> 
            startActivity(new Intent(this, SunCalibrationActivity.class)));
            
        findViewById(R.id.btnGpsCalib).setOnClickListener(v -> 
            startActivity(new Intent(this, GpsCalibrationActivity.class)));
            
        findViewById(R.id.btnGuidance).setOnClickListener(v -> 
            startActivity(new Intent(this, GuidanceActivity.class)));
    }
}

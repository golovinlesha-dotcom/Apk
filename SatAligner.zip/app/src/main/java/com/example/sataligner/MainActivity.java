package com.example.sataligner;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.LinearLayout;

public class MainActivity extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        findViewById(R.id.btnSunCalib).setOnClickListener(v -> 
            startActivity(new Intent(this, SunCalibrationActivity.class)));
            
        findViewById(R.id.btnGpsCalib).setOnClickListener(v -> 
            startActivity(new Intent(this, GpsCalibrationActivity.class)));
            
        findViewById(R.id.btnGuidance).setOnClickListener(v -> 
            startActivity(new Intent(this, GuidanceActivity.class)));
    }
}

#!/bin/bash
echo "=== СБОРКА SATALIGNER ЧЕРЕЗ TERMUX ==="

# 1. Задаем системный Android API, который мы только что установили
SDK_JAR="/data/data/com.termux/files/usr/share/android-tools/android.jar"

# Если путь отличается в вашей версии, ищем его автоматически
if [ ! -f "$SDK_JAR" ]; then
    SDK_JAR=$(find /data/data/com.termux/ -name "android.jar" | head -n 1)
fi

echo "Используем стабильный SDK: $SDK_JAR"

# 2. Очистка старых логов AndroidIDE
rm -rf buildgen && mkdir -p buildgen/obj buildgen/apk

echo "Шаг 1: Сборка интерфейса и ресурсов (AAPT2)..."
aapt2 compile --dir app/src/main/res -o buildgen/res.zip
aapt2 link --manifest app/src/main/AndroidManifest.xml -I "$SDK_JAR" -o buildgen/apk/base.apk buildgen/res.zip --java app/src/main/java

echo "Шаг 2: Компиляция Java кода приложения..."
find app/src/main/java -name "*.java" > buildgen/sources.txt
ecj -d buildgen/obj -source 1.8 -target 1.8 -classpath "$SDK_JAR" @buildgen/sources.txt

echo "Шаг 3: Конвертация классов в формат Android DEX..."
# Собираем все скомпилированные классы в один файл
cd buildgen/obj
zip -r ../classes.zip ./* > /dev/null
cd ../..
d8 --output buildgen/apk/classes.dex buildgen/classes.zip

echo "Шаг 4: Упаковка финального APK-файла..."
cd buildgen/apk
zip -r ../../SatAligner_Termux.apk ./* > /dev/null
cd ../..

echo "Шаг 5: Цифровая подпись APK..."
apksigner debug SatAligner_Termux.apk

echo "=== СБОРКА ЗАВЕРШЕНА УСПЕШНО! ==="
cp SatAligner_Termux.apk /sdcard/Download/
echo "Установочный файл скопирован в Загрузки телефона под именем: SatAligner_Termux.apk"

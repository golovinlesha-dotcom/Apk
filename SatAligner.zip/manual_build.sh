#!/bin/bash
echo "=== STARTING PRECISE INDEPENDENT BUILD ==?"

rm -rf buildgen && mkdir -p buildgen/obj buildgen/apk

echo "Step 1: Compiling Android Resources (AAPT2)..."
aapt2 compile --dir app/src/main/res -o buildgen/res.zip
aapt2 link --manifest app/src/main/AndroidManifest.xml -o buildgen/SatAligner_unaligned.apk buildgen/res.zip --java app/src/main/java

echo "Step 2: Compiling Pure Java Code via internal environment..."
find app/src/main/java -name "*.java" > buildgen/sources.txt

# Компилируем без bootclasspath, используя встроенные в среду JDK-библиотеки смартфона
javac -encoding UTF-8 -target 1.8 -source 1.8 -d buildgen/obj @buildgen/sources.txt

echo "=== PRE-COMPILATION FINISHED ==="
echo "Please return to the visual AndroidIDE window and click the main 'BUILD/PLAY' icon."

#!/bin/bash
echo "=== ЗАПУСК ПРЯМОЙ СБОРКИ БЕЗ GRADLE ==="

# Проверяем стандартные пути размещения Android SDK в AndroidIDE
if [ -f "$HOME/.androidide/sdk/platforms/android-34/android.jar" ]; then
    SDK_JAR="$HOME/.androidide/sdk/platforms/android-34/android.jar"
elif [ -f "$HOME/.androidide/sdk/platforms/android-33/android.jar" ]; then
    SDK_JAR="$HOME/.androidide/sdk/platforms/android-33/android.jar"
elif [ -f "$HOME/.androidide/sdk/platforms/android-30/android.jar" ]; then
    SDK_JAR="$HOME/.androidide/sdk/platforms/android-30/android.jar"
else
    # Тотальный поиск без учета регистра по внутренней папке приложения
    SDK_JAR=$(find $HOME -name "android.jar" -print -quit 2>/dev/null)
fi

# Если вообще не нашли, берем из кэша самого Gradle (он там точно есть)
if [ -z "$SDK_JAR" ]; then
    SDK_JAR=$(find $HOME/.gradle/caches/ -name "android.jar" -print -quit 2>/dev/null)
fi

# Финальная проверка
if [ -z "$SDK_JAR" ] || [ ! -f "$SDK_JAR" ]; then
    echo "Критическая ошибка: Системный файл android.jar не обнаружен."
    echo "Попробуем скомпилировать стандартным Java-окружением..."
    SDK_JAR=""
fi

echo "Используем Android API: $SDK_JAR"

rm -rf buildgen && mkdir -p buildgen/obj buildgen/apk

echo "Шаг 1: Сборка XML ресурсов..."
aapt2 compile --dir app/src/main/res -o buildgen/res.zip
if [ -n "$SDK_JAR" ]; then
    aapt2 link --manifest app/src/main/AndroidManifest.xml -I "$SDK_JAR" -o buildgen/apk/base.apk buildgen/res.zip --java app/src/main/java
else
    aapt2 link --manifest app/src/main/AndroidManifest.xml -o buildgen/apk/base.apk buildgen/res.zip --java app/src/main/java
fi

echo "Шаг 2: Компиляция исходного Java кода (UTF-8)..."
find app/src/main/java -name "*.java" > buildgen/sources.txt

if [ -n "$SDK_JAR" ]; then
    javac -encoding UTF-8 -target 1.8 -source 1.8 -bootclasspath "$SDK_JAR" -d buildgen/obj @buildgen/sources.txt
else
    javac -encoding UTF-8 -target 1.8 -source 1.8 -d buildgen/obj @buildgen/sources.txt
fi

echo "Шаг 3: Перевод в DEX-формат..."
d8 --output buildgen/apk/classes.dex buildgen/obj/com/example/sataligner/*.class

echo "Шаг 4: Упаковка APK..."
cd buildgen/apk
zip -r ../../SatAligner_PureNative.apk ./* > /dev/null
cd ../..

echo "Шаг 5: Подпись пакета..."
apksigner debug SatAligner_PureNative.apk

echo "=== СБОРКА ПРОШЛА УСПЕШНО! ==="
cp SatAligner_PureNative.apk /sdcard/Download/
echo "Файл готов! Ищите его в папке 'Загрузки' телефона: SatAligner_PureNative.apk"
